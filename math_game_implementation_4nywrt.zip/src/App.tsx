import { Authenticated, Unauthenticated, useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { useState, useEffect, useCallback } from "react";

function generateProblem() {
  const operations = ['+', '-', '*'];
  const op = operations[Math.floor(Math.random() * operations.length)];
  let a, b;
  
  switch(op) {
    case '+':
      a = Math.floor(Math.random() * 20) + 1; // 1 to 20
      b = Math.floor(Math.random() * 20) + 1; // 1 to 20
      break;
    case '-':
      a = Math.floor(Math.random() * 20) + 1; // 1 to 20
      b = Math.floor(Math.random() * a); // Ensures positive result
      break;
    case '*':
      a = Math.floor(Math.random() * 10) + 1; // 1 to 10
      b = Math.floor(Math.random() * 10) + 1; // 1 to 10
      break;
    default:
      a = 0;
      b = 0;
  }
  
  return {
    problem: `${a} ${op} ${b}`,
    answer: eval(`${a} ${op} ${b}`),
  };
}

function Game() {
  const [timeLeft, setTimeLeft] = useState(60);
  const [totalTime, setTotalTime] = useState(60);
  const [score, setScore] = useState(0);
  const [gameActive, setGameActive] = useState(false);
  const [showMenu, setShowMenu] = useState(true);
  const [currentProblem, setCurrentProblem] = useState(generateProblem());
  const [answer, setAnswer] = useState("");
  const highScore = useQuery(api.scores.getHighScore) ?? 0;
  const saveScore = useMutation(api.scores.saveScore);

  useEffect(() => {
    if (!gameActive) return;
    
    if (timeLeft === 0) {
      setGameActive(false);
      saveScore({ score });
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft(t => t - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, gameActive, score, saveScore]);

  const startGame = useCallback((seconds: number) => {
    setTotalTime(seconds);
    setTimeLeft(seconds);
    setScore(0);
    setGameActive(true);
    setShowMenu(false);
    setCurrentProblem(generateProblem());
    setAnswer("");
  }, []);

  const quitGame = useCallback(() => {
    setGameActive(false);
    setShowMenu(true);
    setTimeLeft(totalTime);
    setScore(0);
    setAnswer("");
  }, [totalTime]);

  const backToMenu = useCallback(() => {
    setShowMenu(true);
    setTimeLeft(totalTime);
    setScore(0);
    setAnswer("");
  }, [totalTime]);

  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    if (!gameActive) return;

    if (parseInt(answer) === currentProblem.answer) {
      setScore(s => s + 1);
    }
    setCurrentProblem(generateProblem());
    setAnswer("");
  }, [answer, currentProblem, gameActive]);

  return (
    <div className="flex flex-col items-center gap-6 p-6 bg-slate-800 rounded-xl shadow-xl">
      <div className="flex justify-between w-full">
        <div className="text-slate-300">Time: {timeLeft}s</div>
        <div className="text-slate-300">Score: {score}</div>
      </div>
      <div className="text-slate-300">High Score: {highScore}</div>
      
      {showMenu && (
        <div className="text-center">
          <h3 className="text-xl text-slate-300 mb-6">Choose Game Duration:</h3>
          <div className="flex flex-col gap-4">
            <button
              onClick={() => startGame(60)}
              className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 transition"
            >
              1 Minute
            </button>
            <button
              onClick={() => startGame(180)}
              className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 transition"
            >
              3 Minutes
            </button>
            <button
              onClick={() => startGame(300)}
              className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 transition"
            >
              5 Minutes
            </button>
          </div>
        </div>
      )}
      
      {!gameActive && !showMenu && timeLeft === 0 && (
        <div className="text-center">
          <div className="text-2xl text-slate-300 mb-4">Game Over!</div>
          <div className="text-xl text-slate-300 mb-6">Final Score: {score}</div>
          <div className="flex gap-4">
            <button
              onClick={() => startGame(totalTime)}
              className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 transition"
            >
              Play Again
            </button>
            <button
              onClick={backToMenu}
              className="px-4 py-2 bg-slate-600 text-white rounded hover:bg-slate-700 transition"
            >
              Back to Menu
            </button>
          </div>
        </div>
      )}
      
      {gameActive && (
        <form onSubmit={handleSubmit} className="flex flex-col items-center gap-4">
          <div className="text-3xl font-bold text-slate-200">{currentProblem.problem} = ?</div>
          <input
            type="number"
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
            className="px-4 py-2 bg-slate-700 text-white rounded border border-slate-600 focus:outline-none focus:border-indigo-500"
            autoFocus
          />
          <div className="flex gap-4">
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 transition"
            >
              Submit
            </button>
            <button
              type="button"
              onClick={quitGame}
              className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition"
            >
              Quit Game
            </button>
          </div>
        </form>
      )}
    </div>
  );
}

export default function App() {
  return (
    <div className="min-h-screen flex flex-col bg-slate-900">
      <header className="sticky top-0 z-10 bg-slate-800/80 backdrop-blur-sm p-4 flex justify-between items-center border-b border-slate-700">
        <h2 className="text-xl font-semibold text-white">Math Sprint</h2>
        <SignOutButton />
      </header>
      <main className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-md mx-auto">
          <Authenticated>
            <Game />
          </Authenticated>
          <Unauthenticated>
            <div className="bg-slate-800 p-8 rounded-xl">
              <div className="text-center mb-8">
                <h1 className="text-4xl font-bold text-white mb-4">Math Sprint</h1>
                <p className="text-xl text-slate-300">Sign in to play!</p>
              </div>
              <SignInForm />
            </div>
          </Unauthenticated>
        </div>
      </main>
      <Toaster />
    </div>
  );
}
