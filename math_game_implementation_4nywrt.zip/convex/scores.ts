import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const saveScore = mutation({
  args: { score: v.number() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;
    await ctx.db.insert("scores", {
      userId,
      score: args.score,
    });
  },
});

export const getHighScore = query({
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return 0;
    
    const scores = await ctx.db
      .query("scores")
      .withIndex("by_user", q => q.eq("userId", userId))
      .collect();
    
    if (scores.length === 0) return 0;
    return Math.max(...scores.map(s => s.score));
  },
});
